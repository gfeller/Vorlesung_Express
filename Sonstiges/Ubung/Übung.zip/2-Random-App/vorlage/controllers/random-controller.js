export function index(req, res) {
    res.render('random', {title: 'Random'});
}

// TODO
